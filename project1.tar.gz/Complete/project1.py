#!/usr/bin/env python
import numpy as np
import glob
import pylab as P
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

files = glob.glob("Out*.dat")
datas = np.array([np.loadtxt( f, dtype=float, skiprows=10, usecols=(0,3,6,9)) for f in files])
other = np.array([0,0,0,0])
for data in datas:
    other = np.vstack((other, np.array([val for val in data if val[0] ==710 or val[0] == 2201], ndmin=1)))

datas = other
z = np.array([val[1] for val in datas])
fz = np.array([val[2] for val in datas])
vz = np.array([val[3] for val in datas])
uz = np.array([val[3]/100 for val in datas])
time = np.arange(len(uz))*100

# using numpy determine the standard deviation
uz_std = np.std(uz)
print uz_std
################## plot some values #################
'''
plt.plot(time, uz, label="u_z vs. Timesteps")
plt.legend()
plt.show()
'''
################# get max values ####################

z_lim  = np.array([max( z), min( z)])
fz_lim = np.array([max(fz), min(fz)])
uz_lim = np.array([max(uz), min(uz)])
vz_lim = np.array([max(vz), min(vz)])

################ plot histogram #####################

dbin = (uz_lim[0]-uz_lim[1])/10
bins = np.arange(uz_lim[1], uz_lim[0]+dbin, dbin)
print bins
plt.hist( uz, 10, label="displacement")
plt.legend()
plt.show()

#####################################################
if __name__ == "__main__":
    print 'ready set go'
